1. Your name(s):
2. Collaboration statement:
3. About how long did this project take you?
